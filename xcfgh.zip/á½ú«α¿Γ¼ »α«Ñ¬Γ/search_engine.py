"""
Модуль для поиска игр.
Реализует различные алгоритмы поиска с использованием принципов алгоритмизации.
"""

from typing import List, Callable
from game import Game


class SearchEngine:
    """
    Класс для поиска игр.
    
    Реализует различные алгоритмы поиска:
    - Линейный поиск
    - Бинарный поиск (для отсортированных списков)
    - Поиск с использованием фильтров
    """
    
    def __init__(self, games: List[Game]):
        """
        Инициализация поискового движка.
        
        Args:
            games: Список игр для поиска
        """
        self._games = games
        self._sorted_games = None
    
    def linear_search(self, query: str, field: str = "title") -> List[Game]:
        """
        Линейный поиск по списку игр.
        
        Временная сложность: O(n)
        Пространственная сложность: O(1)
        
        Args:
            query: Поисковый запрос
            field: Поле для поиска (title, genre, platform)
            
        Returns:
            Список найденных игр
        """
        query_lower = query.lower()
        results = []
        
        for game in self._games:
            value = self._get_field_value(game, field)
            if query_lower in value.lower():
                results.append(game)
        
        return results
    
    def binary_search_by_title(self, query: str) -> List[Game]:
        """
        Бинарный поиск по названию (требует отсортированный список).
        
        Временная сложность: O(log n) для одного элемента
        Пространственная сложность: O(1)
        
        Args:
            query: Поисковый запрос
            
        Returns:
            Список найденных игр
        """
        if self._sorted_games is None:
            self._sorted_games = sorted(self._games, key=lambda g: g.title.lower())
        
        query_lower = query.lower()
        results = []
        
        # Используем бинарный поиск для нахождения первого совпадения
        left, right = 0, len(self._sorted_games) - 1
        found_index = -1
        
        while left <= right:
            mid = (left + right) // 2
            mid_title = self._sorted_games[mid].title.lower()
            
            if mid_title.startswith(query_lower):
                found_index = mid
                break
            elif mid_title < query_lower:
                left = mid + 1
            else:
                right = mid - 1
        
        # Если найдено совпадение, ищем все похожие элементы
        if found_index != -1:
            # Ищем влево
            i = found_index
            while i >= 0 and self._sorted_games[i].title.lower().startswith(query_lower):
                if query_lower in self._sorted_games[i].title.lower():
                    results.append(self._sorted_games[i])
                i -= 1
            
            # Ищем вправо
            i = found_index + 1
            while i < len(self._sorted_games) and self._sorted_games[i].title.lower().startswith(query_lower):
                if query_lower in self._sorted_games[i].title.lower():
                    results.append(self._sorted_games[i])
                i += 1
        
        return results
    
    def advanced_search(self, query: str, 
                       search_fields: List[str] = None) -> List[Game]:
        """
        Расширенный поиск по нескольким полям одновременно.
        
        Использует линейный поиск с проверкой нескольких полей.
        Временная сложность: O(n * m), где n - количество игр, m - количество полей
        
        Args:
            query: Поисковый запрос
            search_fields: Список полей для поиска (по умолчанию: title, genre, description)
            
        Returns:
            Список найденных игр
        """
        if search_fields is None:
            search_fields = ["title", "genre", "description"]
        
        query_lower = query.lower()
        results = []
        seen = set()  # Для избежания дубликатов
        
        for game in self._games:
            for field in search_fields:
                value = self._get_field_value(game, field)
                if query_lower in value.lower() and game not in seen:
                    results.append(game)
                    seen.add(game)
                    break
        
        return results
    
    def _get_field_value(self, game: Game, field: str) -> str:
        """
        Получает значение поля игры.
        
        Args:
            game: Объект игры
            field: Название поля
            
        Returns:
            Значение поля в виде строки
        """
        field_map = {
            "title": game.title,
            "genre": game.genre,
            "platform": game.platform,
            "description": game.description,
            "release_date": game.release_date
        }
        return field_map.get(field, "")
    
    def update_games(self, games: List[Game]):
        """
        Обновляет список игр.
        
        Args:
            games: Новый список игр
        """
        self._games = games
        self._sorted_games = None  # Сбрасываем отсортированный список

