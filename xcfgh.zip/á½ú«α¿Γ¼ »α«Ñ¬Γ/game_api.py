"""
Модуль для работы с API игр.
Реализует класс GameAPI для получения данных о играх.
"""

import requests
import json
from typing import List, Optional
from game import Game


class GameAPI:
    """
    Класс для работы с API игр.
    
    Инкапсулирует логику подключения к внешнему API
    и получения информации об играх.
    """
    
    def __init__(self, api_url: str = "https://www.freetogame.com/api/games"):
        """
        Инициализация API клиента.
        
        Args:
            api_url: URL API для получения игр
        """
        self._api_url = api_url
        self._session = requests.Session()
        self._session.headers.update({
            'User-Agent': 'GameLauncher/1.0',
            'Accept': 'application/json'
        })
    
    def fetch_games(self) -> List[Game]:
        """
        Получает список игр с API.
        
        Returns:
            Список объектов Game
            
        Raises:
            requests.RequestException: При ошибке подключения
        """
        try:
            response = self._session.get(self._api_url, timeout=10)
            response.raise_for_status()
            games_data = response.json()
            
            games = []
            for game_data in games_data:
                game = self._parse_game_data(game_data)
                if game:
                    games.append(game)
            
            return games
            
        except requests.RequestException as e:
            print(f"Ошибка при получении данных: {e}")
            # Возвращаем тестовые данные при ошибке подключения
            return self._get_fallback_games()
    
    def _parse_game_data(self, data: dict) -> Optional[Game]:
        """
        Парсит данные игры из JSON.
        
        Args:
            data: Словарь с данными игры
            
        Returns:
            Объект Game или None
        """
        try:
            title = data.get('title', 'Unknown')
            genre = data.get('genre', 'Unknown')
            platform = data.get('platform', 'Unknown')
            release_date = data.get('release_date', 'Unknown')
            rating = float(data.get('rating', 0))
            description = data.get('short_description', '')
            
            return Game(
                title=title,
                genre=genre,
                platform=platform,
                release_date=release_date,
                rating=rating,
                description=description
            )
        except (ValueError, KeyError) as e:
            print(f"Ошибка парсинга данных игры: {e}")
            return None
    
    def _get_fallback_games(self) -> List[Game]:
        """
        Возвращает тестовые игры при недоступности API.
        
        Returns:
            Список тестовых игр
        """
        return [
            Game("The Witcher 3", "RPG", "PC", "2015-05-19", 9.7, 
                 "Эпическая RPG игра от CD Projekt RED"),
            Game("Cyberpunk 2077", "RPG", "PC", "2020-12-10", 7.5,
                 "Футуристическая RPG в открытом мире"),
            Game("Minecraft", "Sandbox", "Multi-platform", "2011-11-18", 9.0,
                 "Популярная игра-песочница"),
            Game("Counter-Strike 2", "FPS", "PC", "2023-09-27", 8.5,
                 "Командный шутер от первого лица"),
            Game("Valorant", "FPS", "PC", "2020-06-02", 8.0,
                 "Тактический шутер от Riot Games"),
            Game("League of Legends", "MOBA", "PC", "2009-10-27", 8.2,
                 "Популярная MOBA игра"),
            Game("Dota 2", "MOBA", "PC", "2013-07-09", 8.8,
                 "Командная стратегия в реальном времени"),
            Game("Grand Theft Auto V", "Action", "Multi-platform", "2013-09-17", 9.5,
                 "Открытый мир с криминальным сюжетом"),
        ]

