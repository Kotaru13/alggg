"""
Модуль для фильтрации игр.
Реализует различные алгоритмы фильтрации.
"""

from typing import List, Optional, Callable
from game import Game


class FilterEngine:
    """
    Класс для фильтрации игр.
    
    Реализует алгоритмы фильтрации с использованием
    различных критериев и условий.
    """
    
    def __init__(self, games: List[Game]):
        """
        Инициализация фильтрующего движка.
        
        Args:
            games: Список игр для фильтрации
        """
        self._games = games
    
    def filter_by_genre(self, genre: str) -> List[Game]:
        """
        Фильтрация по жанру.
        
        Временная сложность: O(n)
        
        Args:
            genre: Жанр для фильтрации
            
        Returns:
            Отфильтрованный список игр
        """
        if not genre:
            return self._games
        
        genre_lower = genre.lower()
        return [game for game in self._games if game.genre.lower() == genre_lower]
    
    def filter_by_platform(self, platform: str) -> List[Game]:
        """
        Фильтрация по платформе.
        
        Временная сложность: O(n)
        
        Args:
            platform: Платформа для фильтрации
            
        Returns:
            Отфильтрованный список игр
        """
        if not platform:
            return self._games
        
        platform_lower = platform.lower()
        return [game for game in self._games 
                if platform_lower in game.platform.lower()]
    
    def filter_by_rating(self, min_rating: float = 0.0, 
                         max_rating: float = 10.0) -> List[Game]:
        """
        Фильтрация по рейтингу.
        
        Временная сложность: O(n)
        
        Args:
            min_rating: Минимальный рейтинг
            max_rating: Максимальный рейтинг
            
        Returns:
            Отфильтрованный список игр
        """
        return [game for game in self._games 
                if min_rating <= game.rating <= max_rating]
    
    def filter_by_multiple_criteria(self, 
                                   genre: Optional[str] = None,
                                   platform: Optional[str] = None,
                                   min_rating: Optional[float] = None,
                                   max_rating: Optional[float] = None) -> List[Game]:
        """
        Фильтрация по нескольким критериям одновременно.
        
        Использует алгоритм последовательной фильтрации.
        Временная сложность: O(n * k), где k - количество критериев
        
        Args:
            genre: Жанр
            platform: Платформа
            min_rating: Минимальный рейтинг
            max_rating: Максимальный рейтинг
            
        Returns:
            Отфильтрованный список игр
        """
        filtered = self._games
        
        if genre:
            filtered = self.filter_by_genre(genre)
        
        if platform:
            filtered = [g for g in filtered 
                       if platform.lower() in g.platform.lower()]
        
        if min_rating is not None:
            filtered = [g for g in filtered if g.rating >= min_rating]
        
        if max_rating is not None:
            filtered = [g for g in filtered if g.rating <= max_rating]
        
        return filtered
    
    def get_unique_genres(self) -> List[str]:
        """
        Получает список уникальных жанров.
        
        Временная сложность: O(n)
        
        Returns:
            Список уникальных жанров
        """
        genres = set()
        for game in self._games:
            genres.add(game.genre)
        return sorted(list(genres))
    
    def get_unique_platforms(self) -> List[str]:
        """
        Получает список уникальных платформ.
        
        Временная сложность: O(n)
        
        Returns:
            Список уникальных платформ
        """
        platforms = set()
        for game in self._games:
            platforms.add(game.platform)
        return sorted(list(platforms))
    
    def sort_by_rating(self, reverse: bool = True) -> List[Game]:
        """
        Сортировка по рейтингу.
        
        Использует алгоритм сортировки Timsort (встроенный в Python).
        Временная сложность: O(n log n)
        
        Args:
            reverse: Сортировать по убыванию (True) или возрастанию (False)
            
        Returns:
            Отсортированный список игр
        """
        return sorted(self._games, key=lambda g: g.rating, reverse=reverse)
    
    def sort_by_title(self, reverse: bool = False) -> List[Game]:
        """
        Сортировка по названию.
        
        Временная сложность: O(n log n)
        
        Args:
            reverse: Сортировать в обратном порядке
            
        Returns:
            Отсортированный список игр
        """
        return sorted(self._games, key=lambda g: g.title.lower(), reverse=reverse)
    
    def update_games(self, games: List[Game]):
        """
        Обновляет список игр.
        
        Args:
            games: Новый список игр
        """
        self._games = games

