"""
Главный модуль для запуска лаунчера игр.
"""

import sys

def check_dependencies():
    """Проверяет наличие необходимых зависимостей."""
    missing = []
    
    try:
        import tkinter
    except ImportError:
        missing.append("tkinter (обычно встроен в Python)")
    
    try:
        import requests
    except ImportError:
        missing.append("requests - установите: pip install requests")
    
    if missing:
        print("Ошибка: отсутствуют необходимые библиотеки:")
        for lib in missing:
            print(f"  - {lib}")
        print("\nУстановите недостающие библиотеки и попробуйте снова.")
        input("Нажмите Enter для выхода...")
        return False
    return True

def main():
    """Главная функция запуска."""
    if not check_dependencies():
        sys.exit(1)
    
    try:
        from launcher_gui import main as launcher_main
        launcher_main()
    except KeyboardInterrupt:
        print("\n\nПриложение закрыто пользователем.")
        sys.exit(0)
    except Exception as e:
        print(f"\nОшибка при запуске приложения: {e}")
        import traceback
        traceback.print_exc()
        input("\nНажмите Enter для выхода...")
        sys.exit(1)

if __name__ == "__main__":
    main()

