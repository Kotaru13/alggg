"""
Модуль для представления игр.
Реализует класс Game с использованием принципов ООП.
"""


class Game:
    """
    Класс для представления игры.
    
    Инкапсулирует все данные об игре и предоставляет методы
    для работы с ними.
    """
    
    def __init__(self, title: str, genre: str, platform: str, 
                 release_date: str, rating: float, description: str = ""):
        """
        Инициализация объекта игры.
        
        Args:
            title: Название игры
            genre: Жанр игры
            platform: Платформа
            release_date: Дата выхода
            rating: Рейтинг (0-10)
            description: Описание игры
        """
        self._title = title
        self._genre = genre
        self._platform = platform
        self._release_date = release_date
        self._rating = rating
        self._description = description
    
    @property
    def title(self) -> str:
        """Возвращает название игры."""
        return self._title
    
    @property
    def genre(self) -> str:
        """Возвращает жанр игры."""
        return self._genre
    
    @property
    def platform(self) -> str:
        """Возвращает платформу."""
        return self._platform
    
    @property
    def release_date(self) -> str:
        """Возвращает дату выхода."""
        return self._release_date
    
    @property
    def rating(self) -> float:
        """Возвращает рейтинг."""
        return self._rating
    
    @property
    def description(self) -> str:
        """Возвращает описание."""
        return self._description
    
    def __str__(self) -> str:
        """Строковое представление игры."""
        return f"{self._title} ({self._platform}) - {self._genre} - Рейтинг: {self._rating}"
    
    def __repr__(self) -> str:
        """Представление для отладки."""
        return f"Game(title='{self._title}', genre='{self._genre}', platform='{self._platform}')"
    
    def __eq__(self, other) -> bool:
        """Сравнение игр по названию."""
        if isinstance(other, Game):
            return self._title.lower() == other._title.lower()
        return False
    
    def __hash__(self) -> int:
        """Хеш для использования в множествах."""
        return hash(self._title.lower())

