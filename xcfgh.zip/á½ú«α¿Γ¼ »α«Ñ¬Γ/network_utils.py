"""
Модуль для работы с сетью.
Реализует функционал пинга и проверки соединения.
"""

import socket
import time
import requests
from typing import Optional, Tuple


class NetworkUtils:
    """
    Класс для работы с сетью.
    
    Реализует методы для проверки соединения,
    измерения пинга и работы с сетью.
    """
    
    def __init__(self, host: str = "8.8.8.8", port: int = 53, timeout: int = 3):
        """
        Инициализация утилит сети.
        
        Args:
            host: Хост для проверки соединения (по умолчанию Google DNS)
            port: Порт для проверки
            timeout: Таймаут в секундах
        """
        self._host = host
        self._port = port
        self._timeout = timeout
    
    def ping(self) -> Optional[float]:
        """
        Измеряет пинг до указанного хоста.
        
        Использует TCP соединение для измерения задержки.
        Временная сложность: O(1) - зависит от сетевой задержки
        
        Returns:
            Пинг в миллисекундах или None при ошибке
        """
        try:
            start_time = time.time()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(self._timeout)
            result = sock.connect_ex((self._host, self._port))
            end_time = time.time()
            sock.close()
            
            if result == 0:
                ping_ms = (end_time - start_time) * 1000
                return round(ping_ms, 2)
            else:
                return None
        except (socket.error, socket.timeout, Exception) as e:
            print(f"Ошибка при измерении пинга: {e}")
            return None
    
    def check_connection(self, url: str = "https://www.google.com") -> Tuple[bool, Optional[float]]:
        """
        Проверяет соединение с интернетом.
        
        Args:
            url: URL для проверки
            
        Returns:
            Кортеж (успешность соединения, время ответа в мс)
        """
        try:
            start_time = time.time()
            response = requests.get(url, timeout=5)
            end_time = time.time()
            
            response_time = (end_time - start_time) * 1000
            return (response.status_code == 200, round(response_time, 2))
        except Exception as e:
            print(f"Ошибка проверки соединения: {e}")
            return (False, None)
    
    def get_ping_status(self) -> str:
        """
        Получает статус пинга в виде строки.
        
        Returns:
            Строка со статусом пинга
        """
        ping = self.ping()
        if ping is None:
            return "Нет соединения"
        elif ping < 50:
            return f"Отлично ({ping} мс)"
        elif ping < 100:
            return f"Хорошо ({ping} мс)"
        elif ping < 200:
            return f"Удовлетворительно ({ping} мс)"
        else:
            return f"Плохо ({ping} мс)"

