"""
Модуль графического интерфейса лаунчера.
Реализует главное окно приложения с использованием tkinter.
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from datetime import datetime
import threading
from typing import List, Optional

from game import Game
from game_api import GameAPI
from search_engine import SearchEngine
from filter_engine import FilterEngine
from network_utils import NetworkUtils


class LauncherGUI:
    """
    Класс главного окна лаунчера.
    
    Реализует графический интерфейс с использованием принципов ООП:
    - Инкапсуляция компонентов интерфейса
    - Разделение ответственности
    - Обработка событий
    """
    
    def __init__(self, root: tk.Tk):
        """
        Инициализация главного окна.
        
        Args:
            root: Корневое окно tkinter
        """
        self._root = root
        self._root.title("Game Launcher - Поиск и фильтрация игр")
        self._root.geometry("1200x700")
        self._root.configure(bg="#2b2b2b")
        
        # Инициализация компонентов
        self._game_api = GameAPI()
        self._games: List[Game] = []
        self._filtered_games: List[Game] = []
        self._search_engine: Optional[SearchEngine] = None
        self._filter_engine: Optional[FilterEngine] = None
        self._network_utils = NetworkUtils()
        
        # Создание интерфейса
        self._create_widgets()
        
        # Загрузка игр при запуске
        self._load_games()
        
        # Запуск обновления времени и пинга
        self._update_time_and_ping()
    
    def _create_widgets(self):
        """Создает все виджеты интерфейса."""
        # Верхняя панель с информацией
        self._create_info_panel()
        
        # Панель поиска и фильтров
        self._create_search_panel()
        
        # Список игр
        self._create_games_list()
        
        # Панель деталей игры
        self._create_details_panel()
    
    def _create_info_panel(self):
        """Создает верхнюю панель с датой, временем и пингом."""
        info_frame = tk.Frame(self._root, bg="#1e1e1e", height=60)
        info_frame.pack(fill=tk.X, padx=5, pady=5)
        info_frame.pack_propagate(False)
        
        # Заголовок
        title_label = tk.Label(
            info_frame,
            text="🎮 Game Launcher",
            font=("Arial", 16, "bold"),
            bg="#1e1e1e",
            fg="#ffffff"
        )
        title_label.pack(side=tk.LEFT, padx=10)
        
        # Дата и время
        self._datetime_label = tk.Label(
            info_frame,
            text="",
            font=("Arial", 10),
            bg="#1e1e1e",
            fg="#00ff00"
        )
        self._datetime_label.pack(side=tk.RIGHT, padx=10)
        
        # Пинг
        self._ping_label = tk.Label(
            info_frame,
            text="Пинг: проверка...",
            font=("Arial", 10),
            bg="#1e1e1e",
            fg="#ffff00"
        )
        self._ping_label.pack(side=tk.RIGHT, padx=10)
        
        # Статус загрузки
        self._status_label = tk.Label(
            info_frame,
            text="Загрузка игр...",
            font=("Arial", 10),
            bg="#1e1e1e",
            fg="#00aaff"
        )
        self._status_label.pack(side=tk.RIGHT, padx=10)
    
    def _create_search_panel(self):
        """Создает панель поиска и фильтров."""
        search_frame = tk.Frame(self._root, bg="#2b2b2b")
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Поиск
        search_label = tk.Label(
            search_frame,
            text="Поиск:",
            font=("Arial", 10),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        search_label.pack(side=tk.LEFT, padx=5)
        
        self._search_entry = tk.Entry(
            search_frame,
            font=("Arial", 11),
            width=30,
            bg="#3c3c3c",
            fg="#ffffff",
            insertbackground="#ffffff"
        )
        self._search_entry.pack(side=tk.LEFT, padx=5)
        self._search_entry.bind("<KeyRelease>", self._on_search)
        
        # Кнопка поиска
        search_btn = tk.Button(
            search_frame,
            text="Найти",
            command=self._on_search_click,
            bg="#4a9eff",
            fg="#ffffff",
            font=("Arial", 10),
            relief=tk.FLAT,
            padx=10
        )
        search_btn.pack(side=tk.LEFT, padx=5)
        
        # Фильтр по жанру
        genre_label = tk.Label(
            search_frame,
            text="Жанр:",
            font=("Arial", 10),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        genre_label.pack(side=tk.LEFT, padx=(20, 5))
        
        self._genre_combo = ttk.Combobox(
            search_frame,
            width=15,
            state="readonly"
        )
        self._genre_combo.pack(side=tk.LEFT, padx=5)
        self._genre_combo.bind("<<ComboboxSelected>>", self._on_filter_change)
        
        # Фильтр по платформе
        platform_label = tk.Label(
            search_frame,
            text="Платформа:",
            font=("Arial", 10),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        platform_label.pack(side=tk.LEFT, padx=(20, 5))
        
        self._platform_combo = ttk.Combobox(
            search_frame,
            width=15,
            state="readonly"
        )
        self._platform_combo.pack(side=tk.LEFT, padx=5)
        self._platform_combo.bind("<<ComboboxSelected>>", self._on_filter_change)
        
        # Фильтр по рейтингу
        rating_label = tk.Label(
            search_frame,
            text="Мин. рейтинг:",
            font=("Arial", 10),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        rating_label.pack(side=tk.LEFT, padx=(20, 5))
        
        self._rating_var = tk.DoubleVar(value=0.0)
        rating_scale = tk.Scale(
            search_frame,
            from_=0.0,
            to=10.0,
            resolution=0.1,
            orient=tk.HORIZONTAL,
            variable=self._rating_var,
            bg="#2b2b2b",
            fg="#ffffff",
            highlightbackground="#2b2b2b",
            length=150,
            command=self._on_filter_change
        )
        rating_scale.pack(side=tk.LEFT, padx=5)
        
        # Кнопка сброса фильтров
        reset_btn = tk.Button(
            search_frame,
            text="Сбросить",
            command=self._reset_filters,
            bg="#ff6b6b",
            fg="#ffffff",
            font=("Arial", 10),
            relief=tk.FLAT,
            padx=10
        )
        reset_btn.pack(side=tk.LEFT, padx=10)
    
    def _create_games_list(self):
        """Создает список игр."""
        list_frame = tk.Frame(self._root, bg="#2b2b2b")
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Заголовок списка
        list_header = tk.Label(
            list_frame,
            text="Список игр:",
            font=("Arial", 12, "bold"),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        list_header.pack(anchor=tk.W, pady=(0, 5))
        
        # Список с прокруткой
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self._games_listbox = tk.Listbox(
            list_frame,
            font=("Arial", 10),
            bg="#3c3c3c",
            fg="#ffffff",
            selectbackground="#4a9eff",
            selectforeground="#ffffff",
            yscrollcommand=scrollbar.set,
            height=20
        )
        self._games_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._games_listbox.bind("<<ListboxSelect>>", self._on_game_select)
        
        scrollbar.config(command=self._games_listbox.yview)
    
    def _create_details_panel(self):
        """Создает панель с деталями выбранной игры."""
        details_frame = tk.Frame(self._root, bg="#2b2b2b", width=400)
        details_frame.pack(side=tk.RIGHT, fill=tk.BOTH, padx=5, pady=5)
        details_frame.pack_propagate(False)
        
        # Заголовок
        details_header = tk.Label(
            details_frame,
            text="Детали игры:",
            font=("Arial", 12, "bold"),
            bg="#2b2b2b",
            fg="#ffffff"
        )
        details_header.pack(anchor=tk.W, pady=(0, 5))
        
        # Текстовая область с деталями
        self._details_text = scrolledtext.ScrolledText(
            details_frame,
            font=("Arial", 10),
            bg="#3c3c3c",
            fg="#ffffff",
            wrap=tk.WORD,
            state=tk.DISABLED,
            height=25
        )
        self._details_text.pack(fill=tk.BOTH, expand=True)
    
    def _load_games(self):
        """Загружает игры с API в отдельном потоке."""
        def load():
            try:
                self._status_label.config(text="Загрузка игр...")
                games = self._game_api.fetch_games()
                self._games = games
                self._filtered_games = games
                
                # Инициализация движков
                self._search_engine = SearchEngine(self._games)
                self._filter_engine = FilterEngine(self._games)
                
                # Обновление интерфейса
                self._root.after(0, self._update_games_list)
                self._root.after(0, self._update_filters)
                self._root.after(0, lambda: self._status_label.config(
                    text=f"Загружено игр: {len(games)}"
                ))
            except Exception as e:
                self._root.after(0, lambda: messagebox.showerror(
                    "Ошибка",
                    f"Не удалось загрузить игры: {e}"
                ))
        
        thread = threading.Thread(target=load, daemon=True)
        thread.start()
    
    def _update_games_list(self):
        """Обновляет список игр."""
        self._games_listbox.delete(0, tk.END)
        for game in self._filtered_games:
            self._games_listbox.insert(tk.END, str(game))
    
    def _update_filters(self):
        """Обновляет списки фильтров."""
        if self._filter_engine:
            genres = ["Все"] + self._filter_engine.get_unique_genres()
            platforms = ["Все"] + self._filter_engine.get_unique_platforms()
            
            self._genre_combo["values"] = genres
            self._genre_combo.current(0)
            
            self._platform_combo["values"] = platforms
            self._platform_combo.current(0)
    
    def _on_search(self, event=None):
        """Обработчик поиска при вводе."""
        self._perform_search_and_filter()
    
    def _on_search_click(self):
        """Обработчик кнопки поиска."""
        self._perform_search_and_filter()
    
    def _on_filter_change(self, event=None):
        """Обработчик изменения фильтров."""
        self._perform_search_and_filter()
    
    def _perform_search_and_filter(self):
        """Выполняет поиск и фильтрацию."""
        if not self._search_engine or not self._filter_engine:
            return
        
        # Получаем поисковый запрос
        query = self._search_entry.get().strip()
        
        # Применяем поиск
        if query:
            results = self._search_engine.advanced_search(query)
        else:
            results = self._games
        
        # Применяем фильтры
        genre = self._genre_combo.get()
        platform = self._platform_combo.get()
        min_rating = self._rating_var.get()
        
        filtered = results
        if genre and genre != "Все":
            filtered = self._filter_engine.filter_by_genre(genre)
            filtered = [g for g in filtered if g in results]
        
        if platform and platform != "Все":
            filtered = [g for g in filtered 
                       if platform.lower() in g.platform.lower()]
        
        if min_rating > 0:
            filtered = [g for g in filtered if g.rating >= min_rating]
        
        self._filtered_games = filtered
        self._update_games_list()
        
        # Обновляем статус
        self._status_label.config(
            text=f"Найдено игр: {len(self._filtered_games)}"
        )
    
    def _reset_filters(self):
        """Сбрасывает все фильтры."""
        self._search_entry.delete(0, tk.END)
        self._genre_combo.current(0)
        self._platform_combo.current(0)
        self._rating_var.set(0.0)
        self._filtered_games = self._games
        self._update_games_list()
        self._status_label.config(
            text=f"Загружено игр: {len(self._games)}"
        )
    
    def _on_game_select(self, event):
        """Обработчик выбора игры из списка."""
        selection = self._games_listbox.curselection()
        if not selection:
            return
        
        index = selection[0]
        if index < len(self._filtered_games):
            game = self._filtered_games[index]
            self._show_game_details(game)
    
    def _show_game_details(self, game: Game):
        """Показывает детали выбранной игры."""
        self._details_text.config(state=tk.NORMAL)
        self._details_text.delete(1.0, tk.END)
        
        details = f"""
═══════════════════════════════════════
  {game.title}
═══════════════════════════════════════

Жанр: {game.genre}
Платформа: {game.platform}
Дата выхода: {game.release_date}
Рейтинг: {game.rating}/10

───────────────────────────────────────
Описание:
───────────────────────────────────────

{game.description if game.description else "Описание отсутствует"}

───────────────────────────────────────
"""
        
        self._details_text.insert(1.0, details)
        self._details_text.config(state=tk.DISABLED)
    
    def _update_time_and_ping(self):
        """Обновляет дату, время и пинг."""
        # Обновление даты и времени
        now = datetime.now()
        datetime_str = now.strftime("%d.%m.%Y %H:%M:%S")
        self._datetime_label.config(text=datetime_str)
        
        # Обновление пинга в отдельном потоке
        def update_ping():
            ping_status = self._network_utils.get_ping_status()
            self._root.after(0, lambda: self._ping_label.config(text=f"Пинг: {ping_status}"))
        
        threading.Thread(target=update_ping, daemon=True).start()
        
        # Планируем следующее обновление
        self._root.after(1000, self._update_time_and_ping)


def main():
    """Главная функция для запуска приложения."""
    root = tk.Tk()
    app = LauncherGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()

